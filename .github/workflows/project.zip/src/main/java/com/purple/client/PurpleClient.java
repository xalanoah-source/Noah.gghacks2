package com.purple.client;

import com.purple.client.gui.ClickGui;
import com.purple.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class PurpleClient implements ClientModInitializer {
    public static final String NAME = "Purple";
    public static ModuleManager modules;

    private static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("purpleclient", "main"));
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.purpleclient.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) {
                while (guiKey.wasPressed()) { /* drain */ }
                modules.onWorldLeave();
                return;
            }
            while (guiKey.wasPressed()) {
                client.setScreen(new ClickGui());
            }
            modules.tick();
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of("purpleclient", "hud"),
                (ctx, tickCounter) -> Hud.render(ctx));
    }
}
