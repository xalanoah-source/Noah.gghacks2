package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Smoothly nudges your view toward the nearest valid target.
 * Runs every rendered frame (called from CameraMixin) so the motion is smooth, not 20 Hz steps.
 */
public class AimAssist extends Module {
    private final NumberSetting range = number("Range", 4.5, 1, 8, 0.5);
    private final NumberSetting fov = number("FOV", 90, 10, 360, 10);
    private final NumberSetting speed = number("Speed", 6, 1, 20, 1);
    private final NumberSetting aimHeight = number("Aim Height %", 80, 0, 100, 10);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Hostile Mobs", false);
    private final BoolSetting animals = bool("Animals", false);
    private final BoolSetting onlyAttacking = bool("Only While Attacking", true);
    private final BoolSetting visibleOnly = bool("Visible Only", true);

    private long lastFrame;

    public AimAssist() {
        super("Aim Assist", "Smoothly pulls your aim toward nearby targets.", false);
    }

    /** Called once per rendered frame. */
    public void onFrame() {
        if (!isEnabled() || mc.player == null || mc.world == null) {
            lastFrame = 0;
            return;
        }
        long now = System.nanoTime();
        float dt = lastFrame == 0 ? 0.016f : Math.min((now - lastFrame) / 1_000_000_000f, 0.1f);
        lastFrame = now;

        if (mc.currentScreen != null || Freecam.active) return;
        if (onlyAttacking.get() && !mc.options.attackKey.isPressed()) return;

        Entity target = findTarget();
        if (target == null) return;

        float[] d = anglesTo(target);
        float factor = 1f - (float) Math.exp(-speed.get() * dt);
        // changeLookDirection scales its input by 0.15 (same as mouse movement), so divide that back out.
        mc.player.changeLookDirection(d[0] * factor / 0.15, d[1] * factor / 0.15);
    }

    private Entity findTarget() {
        Entity best = null;
        double bestAngle = Double.MAX_VALUE;
        double halfFov = fov.get() / 2.0;

        for (Entity e : mc.world.getEntities()) {
            if (!Targets.matches(e, players.get(), mobs.get(), animals.get())) continue;
            if (mc.player.distanceTo(e) > range.get()) continue;
            if (visibleOnly.get() && !mc.player.canSee(e)) continue;

            float[] d = anglesTo(e);
            double angle = Math.hypot(d[0], d[1]);
            if (angle > halfFov) continue;
            if (angle < bestAngle) {
                bestAngle = angle;
                best = e;
            }
        }
        return best;
    }

    /** Returns {yawDifference, pitchDifference} in degrees from the current view to the target's aim point. */
    private float[] anglesTo(Entity e) {
        Vec3d eye = mc.player.getEyePos();
        double ax = e.getX();
        double ay = e.getY() + e.getHeight() * (aimHeight.get() / 100.0);
        double az = e.getZ();
        double dx = ax - eye.x;
        double dy = ay - eye.y;
        double dz = az - eye.z;

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        float dYaw = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float dPitch = targetPitch - mc.player.getPitch();
        return new float[] { dYaw, dPitch };
    }
}
