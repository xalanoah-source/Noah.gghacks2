package com.purple.client.module;

import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BrewingStandBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Scans loaded chunks for clusters of player-style block entities
 * (chests, barrels, furnaces, beds, hoppers, shulkers...) and lists the spots.
 */
public class BaseFinder extends Module {
    public record Hit(int x, int y, int z, int score, int distance) {}

    public static final List<Hit> hits = new ArrayList<>();

    /** Chunk score needed to be flagged. Lower = more sensitive, more false positives. */
    private static final int MIN_SCORE = 6;

    private final Set<Long> announced = new HashSet<>();
    private int cooldown = 0;

    public BaseFinder() {
        super("Base Finder", "Flags chunks packed with chests, furnaces, beds, etc.", false);
    }

    @Override
    protected void onEnable() {
        cooldown = 0;
        announced.clear();
        hits.clear();
    }

    @Override
    protected void onDisable() {
        announced.clear();
        hits.clear();
    }

    @Override
    public void onTick() {
        if (cooldown-- > 0) return;
        cooldown = 40; // rescan every 2 seconds
        scan();
    }

    private void scan() {
        ClientWorld world = mc.world;
        ClientPlayerEntity player = mc.player;
        if (world == null || player == null) return;

        int radius = mc.options.getClampedViewDistance();
        int pcx = player.getBlockX() >> 4;
        int pcz = player.getBlockZ() >> 4;
        List<Hit> found = new ArrayList<>();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int cx = pcx + dx;
                int cz = pcz + dz;
                Chunk chunk = world.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;

                int score = 0, n = 0;
                long sx = 0, sy = 0, sz = 0;
                for (BlockPos pos : chunk.getBlockEntityPositions()) {
                    int w = weight(chunk.getBlockEntity(pos));
                    if (w == 0) continue;
                    score += w;
                    n++;
                    sx += pos.getX();
                    sy += pos.getY();
                    sz += pos.getZ();
                }
                if (score < MIN_SCORE || n == 0) continue;

                int x = (int) (sx / n);
                int y = (int) (sy / n);
                int z = (int) (sz / n);
                int dist = (int) Math.sqrt(player.squaredDistanceTo(x, y, z));
                found.add(new Hit(x, y, z, score, dist));

                if (announced.add(ChunkPos.toLong(cx, cz))) {
                    player.sendMessage(Text.literal("[Purple] Possible base near " + x + " " + y + " " + z
                            + " (score " + score + ")").formatted(Formatting.LIGHT_PURPLE), false);
                }
            }
        }

        found.sort(Comparator.comparingInt(Hit::distance));
        hits.clear();
        hits.addAll(found);
    }

    private static int weight(BlockEntity be) {
        if (be == null) return 0;
        if (be instanceof ShulkerBoxBlockEntity) return 2;
        if (be instanceof ChestBlockEntity
                || be instanceof BarrelBlockEntity
                || be instanceof EnderChestBlockEntity
                || be instanceof AbstractFurnaceBlockEntity
                || be instanceof HopperBlockEntity
                || be instanceof DispenserBlockEntity
                || be instanceof BrewingStandBlockEntity
                || be instanceof BedBlockEntity) {
            return 1;
        }
        return 0;
    }
}
