package com.purple.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Shared "is this a valid target?" filter for Aim Assist and Trigger Bot. */
public final class Targets {
    private Targets() {}

    public static boolean matches(Entity e, boolean players, boolean mobs, boolean animals) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!(e instanceof LivingEntity living)) return false;
        if (e == mc.player || !living.isAlive() || e.isSpectator()) return false;
        if (e instanceof PlayerEntity) return players;
        if (e instanceof Monster) return mobs;
        if (e instanceof AnimalEntity) return animals;
        return false;
    }
}
