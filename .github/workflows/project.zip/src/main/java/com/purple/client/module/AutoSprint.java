package com.purple.client.module;

public class AutoSprint extends Module {
    public AutoSprint() {
        super("Auto Sprint", "Sprint whenever you walk forward.", false);
    }

    @Override
    public void onTick() {
        if (mc.player == null || Freecam.active) return;
        if (mc.options.forwardKey.isPressed()
                && !mc.player.isSneaking()
                && !mc.player.horizontalCollision
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
