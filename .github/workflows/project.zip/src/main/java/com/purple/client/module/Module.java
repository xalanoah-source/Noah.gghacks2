package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import com.purple.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    private final String name;
    private final String description;
    private boolean enabled;
    private final boolean disableOnWorldLeave;
    private final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String description, boolean disableOnWorldLeave) {
        this.name = name;
        this.description = description;
        this.disableOnWorldLeave = disableOnWorldLeave;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public boolean isEnabled() { return enabled; }
    public boolean disablesOnWorldLeave() { return disableOnWorldLeave; }
    public List<Setting> getSettings() { return settings; }

    protected NumberSetting number(String name, double def, double min, double max, double step) {
        NumberSetting s = new NumberSetting(name, def, min, max, step);
        settings.add(s);
        return s;
    }

    protected BoolSetting bool(String name, boolean def) {
        BoolSetting s = new BoolSetting(name, def);
        settings.add(s);
        return s;
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
}
