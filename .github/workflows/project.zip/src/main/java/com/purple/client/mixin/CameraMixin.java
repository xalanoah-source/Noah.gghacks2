package com.purple.client.mixin;

import com.purple.client.PurpleClient;
import com.purple.client.module.Freecam;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow protected abstract void setPos(double x, double y, double z);
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow private boolean thirdPerson;

    /** Runs once per rendered frame, before the camera reads the player's rotation. */
    @Inject(method = "update", at = @At("HEAD"))
    private void purple$frame(World area, Entity focused, boolean tp, boolean inverse, float tickProgress, CallbackInfo ci) {
        if (PurpleClient.modules != null) {
            PurpleClient.modules.aimAssist.onFrame();
        }
    }

    @Inject(method = "update", at = @At("TAIL"))
    private void purple$freecam(World area, Entity focused, boolean tp, boolean inverse, float tickProgress, CallbackInfo ci) {
        if (!Freecam.active) return;
        this.setPos(
                MathHelper.lerp(tickProgress, Freecam.prevX, Freecam.x),
                MathHelper.lerp(tickProgress, Freecam.prevY, Freecam.y),
                MathHelper.lerp(tickProgress, Freecam.prevZ, Freecam.z));
        this.setRotation(Freecam.yaw, Freecam.pitch);
        this.thirdPerson = true; // makes your own body render while the camera is detached
    }
}
