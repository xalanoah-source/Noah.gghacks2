package com.purple.client.module;

import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.option.GameOptions;
import net.minecraft.util.math.Vec3d;

public class Freecam extends Module {
    // Read by the mixins.
    public static boolean active;
    public static double x, y, z, prevX, prevY, prevZ;
    public static float yaw, pitch;

    /** An input that never does anything, used to freeze the real player while the camera flies. */
    private KeyboardInput blank;

    public Freecam() {
        super("Freecam", "Detach the camera and fly around. Your body stays put.", true);
    }

    @Override
    protected void onEnable() {
        if (mc.player == null) return;
        if (blank == null) {
            blank = new KeyboardInput(mc.options) {
                @Override
                public void tick() {
                    // intentionally empty
                }
            };
        }
        Vec3d p = mc.player.getEyePos();
        x = prevX = p.x;
        y = prevY = p.y;
        z = prevZ = p.z;
        yaw = mc.player.getYaw();
        pitch = mc.player.getPitch();
        active = true;
    }

    @Override
    protected void onDisable() {
        active = false;
        if (mc.player != null && blank != null && mc.player.input == blank) {
            mc.player.input = new KeyboardInput(mc.options);
        }
    }

    @Override
    public void onTick() {
        if (mc.player == null || blank == null) return;

        // Re-applied every tick in case the player object was replaced (respawn, dimension change).
        if (mc.player.input != blank) {
            mc.player.input = blank;
        }

        prevX = x;
        prevY = y;
        prevZ = z;

        GameOptions o = mc.options;
        double fwd = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double side = (o.rightKey.isPressed() ? 1 : 0) - (o.leftKey.isPressed() ? 1 : 0);
        double up = (o.jumpKey.isPressed() ? 1 : 0) - (o.sneakKey.isPressed() ? 1 : 0);

        double yawR = Math.toRadians(yaw);
        double pitchR = Math.toRadians(pitch);
        double fx = -Math.sin(yawR) * Math.cos(pitchR);
        double fy = -Math.sin(pitchR);
        double fz = Math.cos(yawR) * Math.cos(pitchR);
        double rx = -Math.cos(yawR);
        double rz = -Math.sin(yawR);

        double speed = o.sprintKey.isPressed() ? 2.0 : 0.8; // blocks per tick

        x += (fx * fwd + rx * side) * speed;
        y += (fy * fwd + up) * speed;
        z += (fz * fwd + rz * side) * speed;
    }
}
