package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Attacks automatically while your crosshair is on a valid target. */
public class TriggerBot extends Module {
    private final NumberSetting range = number("Range", 3.0, 1, 6, 0.5);
    private final NumberSetting minCooldown = number("Min Cooldown %", 90, 0, 100, 5);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Hostile Mobs", true);
    private final BoolSetting animals = bool("Animals", false);
    private final BoolSetting skipWhileUsing = bool("Pause While Using Item", true);

    public TriggerBot() {
        super("Trigger Bot", "Attacks when your crosshair is on a target.", false);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null || Freecam.active) return;
        if (skipWhileUsing.get() && mc.player.isUsingItem()) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) return;

        Entity target = entityHit.getEntity();
        if (!Targets.matches(target, players.get(), mobs.get(), animals.get())) return;
        if (mc.player.distanceTo(target) > range.get()) return;
        if (mc.player.getAttackCooldownProgress(0.5f) * 100f < minCooldown.get()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
    }
}
