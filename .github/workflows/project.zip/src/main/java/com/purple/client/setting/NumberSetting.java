package com.purple.client.setting;

import java.util.Locale;

public class NumberSetting extends Setting {
    private double value;
    private final double min, max, step;

    public NumberSetting(String name, double defaultValue, double min, double max, double step) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        set(defaultValue);
    }

    public double get() { return value; }
    public float getF() { return (float) value; }
    public int getInt() { return (int) Math.round(value); }

    public void increase() { set(value + step); }
    public void decrease() { set(value - step); }

    public void set(double v) {
        v = Math.max(min, Math.min(max, v));
        v = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, v));
    }

    public String display() {
        return step >= 1 ? String.valueOf((int) Math.round(value)) : String.format(Locale.ROOT, "%.1f", value);
    }
}
