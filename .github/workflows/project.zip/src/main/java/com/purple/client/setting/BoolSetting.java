package com.purple.client.setting;

public class BoolSetting extends Setting {
    private boolean value;

    public BoolSetting(String name, boolean defaultValue) {
        super(name);
        this.value = defaultValue;
    }

    public boolean get() { return value; }
    public void toggle() { value = !value; }
}
