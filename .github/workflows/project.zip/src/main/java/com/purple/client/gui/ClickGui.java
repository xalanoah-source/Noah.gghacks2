package com.purple.client.gui;

import com.purple.client.PurpleClient;
import com.purple.client.module.Module;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import com.purple.client.setting.Setting;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/**
 * Left panel: modules (click to toggle, click "..." to edit settings).
 * Right panel: settings of the selected module.
 */
public class ClickGui extends Screen {
    private static final int LEFT_W = 150;
    private static final int RIGHT_W = 230;
    private static final int GAP = 8;
    private static final int HEADER_H = 22;
    private static final int ROW_H = 20;
    private static final int SET_H = 18;
    private static final int GEAR_W = 18;
    private static final int BTN = 12;
    private static final int VALUE_W = 36;

    private static Module selected;

    public ClickGui() {
        super(Text.literal("Purple"));
    }

    // ---- layout helpers ----
    private List<Module> mods() { return PurpleClient.modules.all(); }
    private int settingCount() { return selected == null ? 1 : Math.max(1, selected.getSettings().size()); }
    private int leftH() { return HEADER_H + 4 + mods().size() * ROW_H + 4; }
    private int rightH() { return HEADER_H + 4 + settingCount() * SET_H + 4; }
    private int leftX() { return Math.max(2, (width - (LEFT_W + GAP + RIGHT_W)) / 2); }
    private int rightX() { return leftX() + LEFT_W + GAP; }
    private int top() { return Math.max(4, (height - Math.max(leftH(), rightH())) / 2); }
    private int gearX() { return leftX() + LEFT_W - 4 - GEAR_W - 2; }
    private int plusX() { return rightX() + RIGHT_W - 8 - BTN; }
    private int minusX() { return plusX() - 4 - VALUE_W - 4 - BTN; }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private void drawPanel(DrawContext ctx, int x, int y, int w, int h, String title) {
        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, Theme.ACCENT_DARK);
        ctx.fill(x, y, x + w, y + h, Theme.PANEL);
        ctx.fill(x, y, x + w, y + HEADER_H, Theme.HEADER);
        ctx.fill(x, y + HEADER_H - 1, x + w, y + HEADER_H, Theme.ACCENT);
        ctx.drawCenteredTextWithShadow(textRenderer, title, x + w / 2, y + 7, Theme.ACCENT);
    }

    // ---- rendering ----
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, Theme.DIM_BG);

        int top = top();
        int lx = leftX();
        int rx = rightX();
        String tooltip = null;

        // Modules panel
        drawPanel(ctx, lx, top, LEFT_W, leftH(), "MODULES");
        int ry = top + HEADER_H + 4;
        for (Module m : mods()) {
            boolean hover = in(mouseX, mouseY, lx + 4, ry, LEFT_W - 8, ROW_H - 2);
            int bg = m.isEnabled() ? Theme.ROW_ON : (hover ? Theme.ROW_HOVER : Theme.ROW);
            ctx.fill(lx + 4, ry, lx + LEFT_W - 4, ry + ROW_H - 2, bg);
            if (m.isEnabled()) ctx.fill(lx + 4, ry, lx + 6, ry + ROW_H - 2, Theme.ACCENT);

            ctx.drawTextWithShadow(textRenderer, m.getName(), lx + 12, ry + 5, m == selected ? Theme.ACCENT : Theme.TEXT);

            int stateRight = lx + LEFT_W - 10;
            if (!m.getSettings().isEmpty()) {
                int gx = gearX();
                ctx.fill(gx, ry + 2, gx + GEAR_W, ry + ROW_H - 4, m == selected ? Theme.ACCENT_DARK : Theme.HEADER);
                ctx.drawCenteredTextWithShadow(textRenderer, "...", gx + GEAR_W / 2, ry + 5, Theme.TEXT);
                stateRight = gx - 6;
            }
            String state = m.isEnabled() ? "ON" : "OFF";
            ctx.drawTextWithShadow(textRenderer, state, stateRight - textRenderer.getWidth(state), ry + 5,
                    m.isEnabled() ? Theme.ACCENT : Theme.DIM);

            if (hover) tooltip = m.getDescription();
            ry += ROW_H;
        }

        // Settings panel
        String title = selected == null ? "SETTINGS" : selected.getName().toUpperCase() + " SETTINGS";
        drawPanel(ctx, rx, top, RIGHT_W, rightH(), title);
        if (selected == null) {
            ctx.drawCenteredTextWithShadow(textRenderer, "Click ... on a module", rx + RIGHT_W / 2, top + HEADER_H + 10, Theme.DIM);
        } else {
            int sy = top + HEADER_H + 4;
            for (Setting s : selected.getSettings()) {
                boolean hover = in(mouseX, mouseY, rx + 4, sy, RIGHT_W - 8, SET_H - 2);
                boolean on = s instanceof BoolSetting b && b.get();
                int bg = on ? Theme.ROW_ON : (hover ? Theme.ROW_HOVER : Theme.ROW);
                ctx.fill(rx + 4, sy, rx + RIGHT_W - 4, sy + SET_H - 2, bg);
                ctx.drawTextWithShadow(textRenderer, s.getName(), rx + 10, sy + 5, Theme.TEXT);

                if (s instanceof BoolSetting b) {
                    String st = b.get() ? "ON" : "OFF";
                    ctx.drawTextWithShadow(textRenderer, st, rx + RIGHT_W - 10 - textRenderer.getWidth(st), sy + 5,
                            b.get() ? Theme.ACCENT : Theme.DIM);
                } else if (s instanceof NumberSetting n) {
                    drawButton(ctx, minusX(), sy + 2, "-");
                    drawButton(ctx, plusX(), sy + 2, "+");
                    ctx.drawCenteredTextWithShadow(textRenderer, n.display(),
                            minusX() + BTN + 4 + VALUE_W / 2, sy + 5, Theme.ACCENT);
                }
                sy += SET_H;
            }
        }

        if (tooltip != null) {
            ctx.drawCenteredTextWithShadow(textRenderer, tooltip, width / 2,
                    top + Math.max(leftH(), rightH()) + 8, Theme.DIM);
        }
    }

    private void drawButton(DrawContext ctx, int x, int y, String label) {
        ctx.fill(x, y, x + BTN, y + BTN, Theme.ACCENT_DARK);
        ctx.drawCenteredTextWithShadow(textRenderer, label, x + BTN / 2, y + 2, Theme.TEXT);
    }

    // ---- input ----
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int button = click.button();
        if ((button == 0 || button == 1) && client != null && client.player != null) {
            double mx = click.x();
            double my = click.y();
            int top = top();

            // Modules panel
            int lx = leftX();
            int ry = top + HEADER_H + 4;
            for (Module m : mods()) {
                if (in(mx, my, lx + 4, ry, LEFT_W - 8, ROW_H - 2)) {
                    boolean hasSettings = !m.getSettings().isEmpty();
                    boolean gear = hasSettings && mx >= gearX() && mx < gearX() + GEAR_W;
                    if (button == 1 || gear) {
                        if (hasSettings) selected = m;
                    } else {
                        m.toggle();
                    }
                    return true;
                }
                ry += ROW_H;
            }

            // Settings panel
            if (selected != null && button == 0) {
                int rx = rightX();
                int sy = top + HEADER_H + 4;
                for (Setting s : selected.getSettings()) {
                    if (in(mx, my, rx + 4, sy, RIGHT_W - 8, SET_H - 2)) {
                        if (s instanceof BoolSetting b) {
                            b.toggle();
                        } else if (s instanceof NumberSetting n) {
                            if (in(mx, my, minusX(), sy + 2, BTN, BTN)) n.decrease();
                            else if (in(mx, my, plusX(), sy + 2, BTN, BTN)) n.increase();
                        }
                        return true;
                    }
                    sy += SET_H;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
