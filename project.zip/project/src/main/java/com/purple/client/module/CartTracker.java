package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.entity.vehicle.TntMinecartEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Lists the nearest TNT minecarts on the HUD (text only). */
public class CartTracker extends Module {
    private final NumberSetting maxRange = number("Max Range", 64, 8, 128, 8);
    private final NumberSetting lines = number("Lines", 5, 1, 10, 1);
    private final BoolSetting litOnly = bool("Lit Only", false);

    public CartTracker() {
        super("Cart Tracker", "Lists nearby TNT minecarts with distance and fuse.", false);
    }

    public List<String> hudLines() {
        List<String> out = new ArrayList<>();
        if (!isEnabled() || mc.player == null || mc.world == null) return out;
        for (TntMinecartEntity cart : Carts.nearby(maxRange.get())) {
            if (litOnly.get() && !cart.isPrimed()) continue;
            String line = String.format(Locale.ROOT, "Cart %d %d %d (%dm)",
                    cart.getBlockX(), cart.getBlockY(), cart.getBlockZ(), Math.round(mc.player.distanceTo(cart)));
            if (cart.isPrimed()) {
                line += String.format(Locale.ROOT, "  LIT %.1fs", cart.getFuseTicks() / 20.0);
            }
            out.add(line);
            if (out.size() >= lines.getInt()) break;
        }
        return out;
    }
}
