package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Attacks automatically while your crosshair is on a valid target. */
public class TriggerBot extends Module {
    private final NumberSetting range = number("Range", 3.0, 1, 6, 0.5);
    private final NumberSetting minCooldown = number("Min Cooldown %", 100, 0, 100, 5);
    private final NumberSetting extraDelay = number("Extra Delay (ticks)", 5, 0, 40, 1);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Hostile Mobs", true);
    private final BoolSetting animals = bool("Animals", false);
    private final BoolSetting skipWhileUsing = bool("Pause While Using Item", true);

    /** Ticks the target has been "ready to hit" (on crosshair, in range, cooldown reached). */
    private int waited;

    public TriggerBot() {
        super("Trigger Bot", "Attacks when your crosshair is on a target.", false);
    }

    @Override
    protected void onEnable() {
        waited = 0;
    }

    @Override
    public void onTick() {
        Entity target = readyTarget();
        if (target == null) {
            waited = 0;
            return;
        }

        // Wait the extra delay (1 tick = 50 ms) after everything is ready.
        if (waited++ < extraDelay.getInt()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        waited = 0;
    }

    /** Returns the entity under the crosshair if an attack would be allowed right now, else null. */
    private Entity readyTarget() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return null;
        if (mc.currentScreen != null || Freecam.active) return null;
        if (skipWhileUsing.get() && mc.player.isUsingItem()) return null;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) return null;

        Entity target = entityHit.getEntity();
        if (!Targets.matches(target, players.get(), mobs.get(), animals.get())) return null;
        if (mc.player.getEyePos().distanceTo(entityHit.getPos()) > range.get()) return null;
        if (mc.player.getAttackCooldownProgress(0.5f) * 100f < minCooldown.get()) return null;
        return target;
    }
}
