package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

/** One hotkey that steps through rail -> TNT minecart -> igniter on your hotbar. */
public class QuickSetup extends Module {
    private static final Item[][] ROLES = {
            { Items.RAIL, Items.POWERED_RAIL, Items.ACTIVATOR_RAIL, Items.DETECTOR_RAIL },
            { Items.TNT_MINECART },
            { Items.FLINT_AND_STEEL, Items.FIRE_CHARGE }
    };
    private static final String[] NAMES = { "Rail", "TNT Minecart", "Igniter" };

    private final BoolSetting showMessage = bool("Show Message", true);

    public QuickSetup() {
        super("Quick Setup", "Hotkey cycles rail, TNT cart, igniter.", false);
    }

    /** Called by the "Quick Setup: Next Item" key while this module is on. */
    public void cycle() {
        if (mc.player == null) return;

        int current = -1;
        for (int r = 0; r < ROLES.length; r++) {
            if (Hotbar.holding(ROLES[r])) current = r;
        }
        int start = current == -1 ? 0 : (current + 1) % ROLES.length;
        for (int k = 0; k < ROLES.length; k++) {
            int role = (start + k) % ROLES.length;
            if (Hotbar.select(ROLES[role])) {
                if (showMessage.get()) {
                    mc.player.sendMessage(Text.literal("[Purple] " + NAMES[role]), true);
                }
                return;
            }
        }
    }
}
