package com.purple.client;

import com.purple.client.gui.ClickGui;
import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class PurpleClient implements ClientModInitializer {
    public static final String NAME = "Purple";
    public static ModuleManager modules;

    private static KeyBinding guiKey;
    private static KeyBinding quickSetupKey;
    /** One unbound-by-default key per module, set in Options > Controls > Key Binds > Purple Client. */
    private static final Map<Module, KeyBinding> toggleKeys = new LinkedHashMap<>();

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("purpleclient", "main"));
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.purpleclient.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category));
        quickSetupKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.purpleclient.quick_setup",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                category));

        for (Module m : modules.all()) {
            String id = m.getName().toLowerCase(Locale.ROOT).replace(' ', '_');
            toggleKeys.put(m, KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.purpleclient.toggle." + id,
                    InputUtil.Type.KEYSYM,
                    GLFW.GLFW_KEY_UNKNOWN,
                    category)));
        }

        // Restore saved on/off states and settings, and save again when the game closes.
        Config.load(modules);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save(modules));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) {
                while (guiKey.wasPressed()) { /* drain */ }
                while (quickSetupKey.wasPressed()) { /* drain */ }
                for (KeyBinding kb : toggleKeys.values()) {
                    while (kb.wasPressed()) { /* drain */ }
                }
                modules.onWorldLeave();
                return;
            }
            while (guiKey.wasPressed()) {
                client.setScreen(new ClickGui());
            }
            while (quickSetupKey.wasPressed()) {
                if (modules.quickSetup.isEnabled()) modules.quickSetup.cycle();
            }
            for (Map.Entry<Module, KeyBinding> entry : toggleKeys.entrySet()) {
                while (entry.getValue().wasPressed()) {
                    Module m = entry.getKey();
                    m.toggle();
                    Config.save(modules);
                    client.player.sendMessage(
                            Text.literal("[Purple] " + m.getName() + (m.isEnabled() ? " ON" : " OFF")), true);
                }
            }
            modules.tick();
        });

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.of("purpleclient", "hud"),
                (ctx, tickCounter) -> Hud.render(ctx));
    }
}
