package com.purple.client.setting;

import java.util.Locale;

public abstract class Setting {
    private final String name;

    protected Setting(String name) {
        this.name = name;
    }

    public String getName() { return name; }

    /** Stable key used in the saved config file, e.g. "Aim Height %" -> "aim_height". */
    public String getId() {
        String id = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_");
        return id.replaceAll("^_+|_+$", "");
    }
}
