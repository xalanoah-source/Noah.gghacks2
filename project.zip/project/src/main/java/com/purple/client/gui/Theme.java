package com.purple.client.gui;

public final class Theme {
    private Theme() {}

    public static final int ACCENT      = 0xFFB066FF;
    public static final int ACCENT_DARK = 0xFF7B2FF7;
    public static final int PANEL       = 0xF0170B27;
    public static final int HEADER      = 0xFF2A1250;
    public static final int ROW         = 0xFF22123D;
    public static final int ROW_HOVER   = 0xFF33195C;
    public static final int ROW_ON      = 0xFF4B1E8F;
    public static final int TEXT        = 0xFFEDE3FF;
    public static final int DIM         = 0xFF9A86B8;
    public static final int DIM_BG      = 0x90080312;
    public static final int ALERT       = 0xFFFF5555;
}
