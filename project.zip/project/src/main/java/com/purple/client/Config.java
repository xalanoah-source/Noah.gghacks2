package com.purple.client;

import com.purple.client.module.Module;
import com.purple.client.module.ModuleManager;
import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import com.purple.client.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Saves which modules are on and all their settings to config/purpleclient.properties,
 * and loads them back when the game starts. Delete that file to reset everything.
 */
public final class Config {
    private Config() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("purpleclient.properties");
    }

    public static void load(ModuleManager modules) {
        Path f = file();
        if (!Files.exists(f)) return;

        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f)) {
            p.load(r);
        } catch (IOException | RuntimeException e) {
            System.err.println("[Purple] Couldn't read config: " + e);
            return;
        }

        for (Module m : modules.all()) {
            String prefix = "module." + m.getId() + ".";
            for (Setting s : m.getSettings()) {
                String v = p.getProperty(prefix + s.getId());
                if (v == null) continue;
                try {
                    if (s instanceof BoolSetting b) {
                        b.set(Boolean.parseBoolean(v.trim()));
                    } else if (s instanceof NumberSetting n) {
                        n.set(Double.parseDouble(v.trim()));
                    }
                } catch (NumberFormatException ignored) {
                    // bad value in the file: keep the default
                }
            }
            // Modules that turn themselves off when you leave a world (Freecam) aren't restored as ON.
            if (!m.disablesOnWorldLeave() && Boolean.parseBoolean(p.getProperty(prefix + "enabled", "false").trim())) {
                m.setEnabled(true);
            }
        }
    }

    public static void save(ModuleManager modules) {
        Properties p = new Properties();
        for (Module m : modules.all()) {
            String prefix = "module." + m.getId() + ".";
            p.setProperty(prefix + "enabled", String.valueOf(m.isEnabled()));
            for (Setting s : m.getSettings()) {
                if (s instanceof BoolSetting b) {
                    p.setProperty(prefix + s.getId(), String.valueOf(b.get()));
                } else if (s instanceof NumberSetting n) {
                    p.setProperty(prefix + s.getId(), String.valueOf(n.get()));
                }
            }
        }

        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            try (Writer w = Files.newBufferedWriter(f)) {
                p.store(w, "Purple Client settings (delete this file to reset)");
            }
        } catch (IOException e) {
            System.err.println("[Purple] Couldn't save config: " + e);
        }
    }
}
