package com.purple.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

/** Small hotbar helpers shared by the TNT cart modules. */
public final class Hotbar {
    private Hotbar() {}

    public static boolean holding(Item... items) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return false;
        ItemStack held = mc.player.getMainHandStack();
        for (Item item : items) {
            if (held.isOf(item)) return true;
        }
        return false;
    }

    /** Hotbar slot (0-8) holding any of the items, or -1. */
    public static int find(Item... items) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return -1;
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < PlayerInventory.HOTBAR_SIZE; i++) {
            ItemStack s = inv.getStack(i);
            for (Item item : items) {
                if (s.isOf(item)) return i;
            }
        }
        return -1;
    }

    /** Selects a hotbar slot holding one of the items. True if you're now holding one. */
    public static boolean select(Item... items) {
        if (holding(items)) return true;
        int slot = find(items);
        if (slot == -1) return false;
        MinecraftClient.getInstance().player.getInventory().setSelectedSlot(slot);
        return true;
    }
}
