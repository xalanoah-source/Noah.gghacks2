package com.purple.client;

import com.purple.client.gui.Theme;
import com.purple.client.module.BaseFinder;
import com.purple.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

public final class Hud {
    private Hud() {}

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        TextRenderer tr = mc.textRenderer;

        ctx.drawTextWithShadow(tr, PurpleClient.NAME, 4, 4, Theme.ACCENT);

        // enabled-module list, top right
        int y = 4;
        int right = ctx.getScaledWindowWidth() - 4;
        for (Module m : PurpleClient.modules.all()) {
            if (!m.isEnabled()) continue;
            ctx.drawTextWithShadow(tr, m.getName(), right - tr.getWidth(m.getName()), y, Theme.ACCENT);
            y += 10;
        }

        // TNT cart warning, top center
        String alert = PurpleClient.modules.cartAlert.hudText();
        if (alert != null) {
            ctx.drawCenteredTextWithShadow(tr, alert, ctx.getScaledWindowWidth() / 2, 26, Theme.ALERT);
        }

        // mace fall / smash info, just under the crosshair
        String maceText = PurpleClient.modules.maceAssist.hudText();
        if (maceText != null) {
            ctx.drawCenteredTextWithShadow(tr, maceText, ctx.getScaledWindowWidth() / 2,
                    ctx.getScaledWindowHeight() / 2 + 18, Theme.ACCENT);
        }

        // stash finder results, top left under the watermark
        BaseFinder bf = PurpleClient.modules.baseFinder;
        if (bf.isEnabled() && bf.showOnScreen()) {
            List<BaseFinder.Hit> hits = BaseFinder.hits;
            int ly = 18;
            int shown = Math.min(bf.hudLines(), hits.size());
            for (int i = 0; i < shown; i++) {
                BaseFinder.Hit h = hits.get(i);
                String line = "Stash? " + h.x() + " " + h.y() + " " + h.z() + "  (" + h.distance() + "m)";
                ctx.drawTextWithShadow(tr, line, 4, ly, Theme.TEXT);
                ly += 10;
            }
        }

        // TNT cart list, left side below the stash list
        int cy = 130;
        for (String line : PurpleClient.modules.cartTracker.hudLines()) {
            ctx.drawTextWithShadow(tr, line, 4, cy, Theme.TEXT);
            cy += 10;
        }
    }
}
