package com.purple.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** TNT minecart lookups and a rough blast damage estimate. */
public final class Carts {
    private Carts() {}

    /** TNT minecarts within range of you, nearest first. */
    public static List<TntMinecartEntity> nearby(double range) {
        MinecraftClient mc = MinecraftClient.getInstance();
        List<TntMinecartEntity> out = new ArrayList<>();
        if (mc.player == null || mc.world == null) return out;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof TntMinecartEntity cart && mc.player.distanceTo(cart) <= range) {
                out.add(cart);
            }
        }
        out.sort(Comparator.comparingDouble(c -> mc.player.distanceTo(c)));
        return out;
    }

    /**
     * Rough raw damage from a standing TNT minecart (explosion power 4) at the given distance.
     * Assumes full exposure and ignores armor, so real damage is usually lower.
     */
    public static double blastDamage(double dist) {
        double radius = 8.0; // power 4 * 2
        double impact = 1.0 - dist / radius;
        if (impact <= 0) return 0;
        return (impact * impact + impact) / 2.0 * 7.0 * radius + 1.0;
    }
}
