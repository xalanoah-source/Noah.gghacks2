package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Lights a TNT minecart (flint and steel or fire charge) when a valid target is standing near it.
 * Lighting range is limited by your normal reach, so you'll usually be inside the blast zone:
 * you have to move away during the ~4 second fuse. Min Health stops it from lighting when you're low.
 */
public class AutoLight extends Module {
    private final NumberSetting lightRange = number("Light Range", 4.0, 1, 5, 0.5);
    private final NumberSetting targetRadius = number("Target Radius", 4.0, 1, 8, 0.5);
    private final NumberSetting minHealth = number("Min Health (hp)", 8, 0, 20, 1);
    private final BoolSetting autoSwap = bool("Auto Swap To Igniter", true);
    private final BoolSetting swapBack = bool("Swap Back", true);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Hostile Mobs", false);
    private final BoolSetting animals = bool("Animals", false);

    private int cooldown;
    private int previousSlot = -1;
    private int restoreDelay;

    public AutoLight() {
        super("Auto Light", "Lights TNT carts when a target stands near them.", false);
    }

    @Override
    protected void onEnable() {
        cooldown = 0;
        previousSlot = -1;
        restoreDelay = 0;
    }

    @Override
    protected void onDisable() {
        restore();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (cooldown > 0) cooldown--;
        if (restoreDelay > 0 && --restoreDelay == 0) restore();

        if (cooldown > 0 || mc.currentScreen != null || Freecam.active) return;
        if (mc.player.getHealth() < minHealth.get()) return;

        TntMinecartEntity cart = findCart();
        if (cart == null) return;

        if (!Hotbar.holding(Items.FLINT_AND_STEEL, Items.FIRE_CHARGE)) {
            if (!autoSwap.get()) return;
            int prev = mc.player.getInventory().getSelectedSlot();
            if (!Hotbar.select(Items.FLINT_AND_STEEL, Items.FIRE_CHARGE)) return;
            if (swapBack.get()) previousSlot = prev;
        }

        mc.interactionManager.interactEntity(mc.player, cart, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        cooldown = 10;
        if (previousSlot != -1) restoreDelay = 3;
    }

    private TntMinecartEntity findCart() {
        for (TntMinecartEntity cart : Carts.nearby(lightRange.get())) {
            if (cart.isPrimed()) continue;
            for (Entity e : mc.world.getEntities()) {
                if (Targets.matches(e, players.get(), mobs.get(), animals.get())
                        && e.distanceTo(cart) <= targetRadius.get()) {
                    return cart;
                }
            }
        }
        return null;
    }

    private void restore() {
        if (previousSlot != -1 && mc.player != null) {
            mc.player.getInventory().setSelectedSlot(previousSlot);
        }
        previousSlot = -1;
    }
}
