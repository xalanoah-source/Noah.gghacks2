package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;

/**
 * Mace combat helper (plain vanilla mechanics, no packet tricks):
 *  - tracks how far you've fallen,
 *  - swaps to a mace from your hotbar when you're falling toward a target,
 *  - turns your view toward the target while you fall (Auto Aim),
 *  - hits the target under your crosshair once the fall is big enough and the mace is charged enough,
 *  - swaps back afterwards,
 *  - shows fall distance, an estimate of the smash bonus damage, and your mace charge.
 *
 * Note: swapping to the mace resets its attack charge (about 1.7 seconds to fill), so for full damage
 * hold the mace BEFORE you jump. Min Cooldown % decides how much charge is enough to swing.
 */
public class MaceAssist extends Module {
    private final NumberSetting minFall = number("Min Fall (blocks)", 3.0, 1.5, 30, 0.5);
    private final BoolSetting autoSwap = bool("Auto Swap To Mace", true);
    private final NumberSetting swapFall = number("Swap Fall (blocks)", 0.5, 0.5, 5, 0.5);
    private final NumberSetting swapRange = number("Swap Range", 10, 3, 30, 1);
    private final BoolSetting swapBack = bool("Swap Back", true);
    private final BoolSetting autoAim = bool("Auto Aim", true);
    private final BoolSetting autoAttack = bool("Auto Attack", true);
    private final NumberSetting range = number("Attack Range", 3.0, 1, 6, 0.5);
    private final NumberSetting minCooldown = number("Min Cooldown %", 50, 0, 100, 5);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Hostile Mobs", true);
    private final BoolSetting animals = bool("Animals", false);
    private final BoolSetting showInfo = bool("Show Smash Info", true);

    private double peakY;
    private double fall;
    private int previousSlot = -1;
    private int restoreDelay;
    private long lastFrame;

    public MaceAssist() {
        super("Mace Assist", "Auto-swap to mace, aim and smash targets while falling.", false);
    }

    @Override
    protected void onEnable() {
        peakY = mc.player != null ? mc.player.getY() : 0;
        fall = 0;
        previousSlot = -1;
        restoreDelay = 0;
        lastFrame = 0;
    }

    @Override
    protected void onDisable() {
        restore();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        trackFall();
        handleRestore();

        if (mc.currentScreen != null || Freecam.active) return;
        boolean airborne = !mc.player.isOnGround();

        // Swap early (swapping resets the mace's charge, so it needs time to recharge).
        if (airborne && autoSwap.get() && fall >= swapFall.get() && !holdingMace() && hasTargetNear(swapRange.get())) {
            swapToMace();
        }

        if (!autoAttack.get() || !airborne || fall < minFall.get() || !holdingMace()) return;
        if (mc.interactionManager == null) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) return;
        Entity target = entityHit.getEntity();
        if (!Targets.matches(target, players.get(), mobs.get(), animals.get())) return;
        // Measure from your eyes to the point you're actually hitting (not feet to feet), like the game's own reach.
        if (mc.player.getEyePos().distanceTo(entityHit.getPos()) > range.get()) return;
        if (mc.player.getAttackCooldownProgress(0.5f) * 100f < minCooldown.get()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        peakY = mc.player.getY(); // a smash resets your fall distance
        if (previousSlot != -1) restoreDelay = 3;
    }

    /** Called once per rendered frame (from CameraMixin): smoothly turns toward the nearest target while falling. */
    public void onFrame() {
        if (!isEnabled() || !autoAim.get() || mc.player == null || mc.world == null) {
            lastFrame = 0;
            return;
        }
        long now = System.nanoTime();
        float dt = lastFrame == 0 ? 0.016f : Math.min((now - lastFrame) / 1_000_000_000f, 0.1f);
        lastFrame = now;

        if (mc.currentScreen != null || Freecam.active) return;
        if (mc.player.isOnGround() || fall < 1.5 || !holdingMace()) return;

        Entity target = findAimTarget();
        if (target == null) return;

        Vec3d eye = mc.player.getEyePos();
        double dx = target.getX() - eye.x;
        double dy = target.getY() + target.getHeight() * 0.5 - eye.y;
        double dz = target.getZ() - eye.z;
        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        float dYaw = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float dPitch = targetPitch - mc.player.getPitch();
        float factor = 1f - (float) Math.exp(-14.0 * dt);
        // changeLookDirection scales by 0.15 (same as mouse input), so divide that back out.
        mc.player.changeLookDirection(dYaw * factor / 0.15, dPitch * factor / 0.15);
    }

    /** Text for the HUD (under the crosshair), or null if nothing to show. */
    public String hudText() {
        if (!isEnabled() || !showInfo.get() || mc.player == null || fall < 1.5) return null;
        int charge = Math.round(mc.player.getAttackCooldownProgress(0.5f) * 100f);
        return String.format(Locale.ROOT, "Fall %.1f  |  Smash ~+%.0f dmg  |  Charge %d%%",
                fall, smashBonus(fall), charge);
    }

    /** Approximate bonus damage from the fall: +4/block for 3 blocks, +2/block for the next 5, +1/block after. */
    private static double smashBonus(double d) {
        return Math.min(d, 3) * 4 + Math.max(0, Math.min(d - 3, 5)) * 2 + Math.max(0, d - 8);
    }

    private void trackFall() {
        double y = mc.player.getY();
        if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isClimbing()
                || mc.player.hasVehicle() || mc.player.getAbilities().flying) {
            peakY = y;
        } else {
            peakY = Math.max(peakY, y);
        }
        fall = Math.max(0, peakY - y);
    }

    private boolean holdingMace() {
        return mc.player.getMainHandStack().isOf(Items.MACE);
    }

    private Entity findAimTarget() {
        double max = range.get() + 3.0;
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!Targets.matches(e, players.get(), mobs.get(), animals.get())) continue;
            double d = mc.player.distanceTo(e);
            if (d > max || d >= bestDist) continue;
            bestDist = d;
            best = e;
        }
        return best;
    }

    private boolean hasTargetNear(double radius) {
        for (Entity e : mc.world.getEntities()) {
            if (Targets.matches(e, players.get(), mobs.get(), animals.get())
                    && mc.player.distanceTo(e) <= radius) {
                return true;
            }
        }
        return false;
    }

    private void swapToMace() {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < PlayerInventory.HOTBAR_SIZE; i++) {
            if (inv.getStack(i).isOf(Items.MACE)) {
                if (swapBack.get() && previousSlot == -1) previousSlot = inv.getSelectedSlot();
                inv.setSelectedSlot(i);
                return;
            }
        }
    }

    private void handleRestore() {
        if (previousSlot == -1) return;
        if (restoreDelay > 0) {
            if (--restoreDelay == 0) restore();
            return;
        }
        if (mc.player.isOnGround() || fall < 0.5) restore();
    }

    private void restore() {
        if (previousSlot != -1 && mc.player != null) {
            mc.player.getInventory().setSelectedSlot(previousSlot);
        }
        previousSlot = -1;
    }
}
