package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BrewingStandBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Stash / base finder. Scans loaded chunks for clusters of player-style block entities
 * (chests, barrels, furnaces, beds, hoppers, shulkers...) and lists the spots.
 */
public class BaseFinder extends Module {
    public record Hit(int x, int y, int z, int score, int distance) {}

    public static final List<Hit> hits = new ArrayList<>();

    // --- scanning ---
    private final NumberSetting minScore = number("Min Score", 6, 1, 30, 1);
    private final NumberSetting interval = number("Scan Interval (ticks)", 40, 10, 200, 10);
    private final NumberSetting maxDistance = number("Max Distance", 256, 16, 512, 16);
    // --- output ---
    private final BoolSetting chatAlerts = bool("Chat Alerts", true);
    private final BoolSetting showOnScreen = bool("Show On Screen", true);
    private final NumberSetting hudLines = number("HUD Lines", 5, 1, 10, 1);
    // --- what counts (shulker boxes are worth 2 points, everything else 1) ---
    private final BoolSetting chests = bool("Chests (+Ender)", true);
    private final BoolSetting barrels = bool("Barrels", true);
    private final BoolSetting shulkers = bool("Shulker Boxes", true);
    private final BoolSetting furnaces = bool("Furnaces", true);
    private final BoolSetting hoppers = bool("Hoppers", true);
    private final BoolSetting beds = bool("Beds", true);
    private final BoolSetting misc = bool("Dispensers/Brewing", false);

    private final Set<Long> announced = new HashSet<>();
    private int cooldown = 0;

    public BaseFinder() {
        super("Base Finder", "Finds stashes: chunks packed with chests, furnaces, beds, etc.", false);
    }

    public boolean showOnScreen() { return showOnScreen.get(); }
    public int hudLines() { return hudLines.getInt(); }

    @Override
    protected void onEnable() {
        cooldown = 0;
        announced.clear();
        hits.clear();
    }

    @Override
    protected void onDisable() {
        announced.clear();
        hits.clear();
    }

    @Override
    public void onTick() {
        if (cooldown-- > 0) return;
        cooldown = interval.getInt();
        scan();
    }

    private void scan() {
        ClientWorld world = mc.world;
        ClientPlayerEntity player = mc.player;
        if (world == null || player == null) return;

        int radius = mc.options.getClampedViewDistance();
        int pcx = player.getBlockX() >> 4;
        int pcz = player.getBlockZ() >> 4;
        int needed = minScore.getInt();
        double maxDist = maxDistance.get();
        List<Hit> found = new ArrayList<>();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                int cx = pcx + dx;
                int cz = pcz + dz;
                Chunk chunk = world.getChunk(cx, cz, ChunkStatus.FULL, false);
                if (chunk == null) continue;

                int score = 0, n = 0;
                long sx = 0, sy = 0, sz = 0;
                for (BlockPos pos : chunk.getBlockEntityPositions()) {
                    int w = weight(chunk.getBlockEntity(pos));
                    if (w == 0) continue;
                    score += w;
                    n++;
                    sx += pos.getX();
                    sy += pos.getY();
                    sz += pos.getZ();
                }
                if (score < needed || n == 0) continue;

                int x = (int) (sx / n);
                int y = (int) (sy / n);
                int z = (int) (sz / n);
                double dist = Math.sqrt(player.squaredDistanceTo(x, y, z));
                if (dist > maxDist) continue;
                found.add(new Hit(x, y, z, score, (int) dist));

                if (chatAlerts.get() && announced.add(ChunkPos.toLong(cx, cz))) {
                    player.sendMessage(Text.literal("[Purple] Possible stash near " + x + " " + y + " " + z
                            + " (score " + score + ")").formatted(Formatting.LIGHT_PURPLE), false);
                }
            }
        }

        found.sort(Comparator.comparingInt(Hit::distance));
        hits.clear();
        hits.addAll(found);
    }

    private int weight(BlockEntity be) {
        if (be == null) return 0;
        if (be instanceof ShulkerBoxBlockEntity) return shulkers.get() ? 2 : 0;
        if (be instanceof ChestBlockEntity || be instanceof EnderChestBlockEntity) return chests.get() ? 1 : 0;
        if (be instanceof BarrelBlockEntity) return barrels.get() ? 1 : 0;
        if (be instanceof AbstractFurnaceBlockEntity) return furnaces.get() ? 1 : 0;
        if (be instanceof HopperBlockEntity) return hoppers.get() ? 1 : 0;
        if (be instanceof BedBlockEntity) return beds.get() ? 1 : 0;
        if (be instanceof DispenserBlockEntity || be instanceof BrewingStandBlockEntity) return misc.get() ? 1 : 0;
        return 0;
    }
}
