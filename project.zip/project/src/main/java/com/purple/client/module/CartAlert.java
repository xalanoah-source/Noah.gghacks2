package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.entity.vehicle.TntMinecartEntity;

import java.util.Locale;

/** Warns you on screen when a lit TNT minecart is close. */
public class CartAlert extends Module {
    private final NumberSetting alertRange = number("Alert Range", 12, 4, 40, 2);
    private final BoolSetting showDamage = bool("Show Damage Estimate", true);

    public CartAlert() {
        super("Cart Alert", "Warns when a lit TNT minecart is near you.", false);
    }

    /** Text for the HUD, or null if there's no lit cart in range. */
    public String hudText() {
        if (!isEnabled() || mc.player == null || mc.world == null) return null;
        for (TntMinecartEntity cart : Carts.nearby(alertRange.get())) {
            if (!cart.isPrimed()) continue;
            double dist = mc.player.distanceTo(cart);
            String text = String.format(Locale.ROOT, "TNT CART  %.1fs  |  %.1f blocks",
                    cart.getFuseTicks() / 20.0, dist);
            if (showDamage.get()) {
                text += String.format(Locale.ROOT, "  |  ~%.0f dmg", Carts.blastDamage(dist));
            }
            return text;
        }
        return null;
    }
}
