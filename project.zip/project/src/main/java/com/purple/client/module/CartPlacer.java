package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.BlockState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Sets up a TNT minecart on the target: places a rail where they stand, puts a TNT minecart on it,
 * then (optionally) lights it. Needs a rail, a TNT minecart and an igniter in your hotbar.
 * Everything happens within normal reach, so you'll be close to the blast: move away during the fuse.
 */
public class CartPlacer extends Module {
    private static final Item[] RAILS = { Items.RAIL, Items.POWERED_RAIL, Items.ACTIVATOR_RAIL, Items.DETECTOR_RAIL };
    private static final Item[] IGNITERS = { Items.FLINT_AND_STEEL, Items.FIRE_CHARGE };

    private final NumberSetting targetRange = number("Target Range", 6, 2, 12, 1);
    private final NumberSetting reach = number("Place Reach", 4.0, 2, 5, 0.5);
    private final NumberSetting stepDelay = number("Step Delay (ticks)", 2, 1, 10, 1);
    private final NumberSetting cooldownSetting = number("Cooldown (ticks)", 100, 20, 400, 20);
    private final NumberSetting minHealth = number("Min Health (hp)", 10, 0, 20, 1);
    private final BoolSetting autoLight = bool("Auto Light", true);
    private final BoolSetting swapBack = bool("Swap Back", true);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Hostile Mobs", false);
    private final BoolSetting animals = bool("Animals", false);

    private int stage;        // 0 = idle, 1 = rail placed (need cart), 2 = cart placed (need light)
    private int timer;
    private int retries;
    private int cooldownLeft;
    private int previousSlot = -1;
    private BlockPos railPos;

    public CartPlacer() {
        super("Cart Placer", "Places rail + TNT minecart on a target, then lights it.", false);
    }

    @Override
    protected void onEnable() {
        reset();
        cooldownLeft = 0;
    }

    @Override
    protected void onDisable() {
        restoreSlot();
        reset();
    }

    private void reset() {
        stage = 0;
        timer = 0;
        retries = 0;
        railPos = null;
    }

    private void finish() {
        cooldownLeft = cooldownSetting.getInt();
        restoreSlot();
        reset();
    }

    private void restoreSlot() {
        if (previousSlot != -1 && mc.player != null) {
            mc.player.getInventory().setSelectedSlot(previousSlot);
        }
        previousSlot = -1;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (cooldownLeft > 0) cooldownLeft--;
        if (timer > 0) {
            timer--;
            return;
        }
        if (mc.currentScreen != null || Freecam.active) return;

        switch (stage) {
            case 0 -> start();
            case 1 -> placeCart();
            case 2 -> light();
            default -> reset();
        }
    }

    private void start() {
        if (cooldownLeft > 0 || mc.player.getHealth() < minHealth.get()) return;
        Entity target = findTarget();
        if (target == null) return;

        ClientWorld world = mc.world;
        BlockPos feet = target.getBlockPos();
        BlockState at = world.getBlockState(feet);
        int prev = mc.player.getInventory().getSelectedSlot();

        // A rail is already there: skip straight to the cart.
        if (at.getBlock() instanceof AbstractRailBlock) {
            railPos = feet;
            stage = 1;
            retries = 0;
            if (swapBack.get()) previousSlot = prev;
            return;
        }

        if (!at.isReplaceable()) return;
        BlockPos below = feet.down();
        if (!world.getBlockState(below).isSideSolidFullSquare(world, below, Direction.UP)) return;

        Vec3d hit = new Vec3d(below.getX() + 0.5, below.getY() + 1.0, below.getZ() + 0.5);
        if (mc.player.getEyePos().distanceTo(hit) > reach.get()) return;
        if (!Hotbar.select(RAILS)) return;
        if (swapBack.get()) previousSlot = prev;

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, Direction.UP, below, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        railPos = feet;
        stage = 1;
        retries = 0;
        timer = stepDelay.getInt();
    }

    private void placeCart() {
        BlockState st = mc.world.getBlockState(railPos);
        if (!(st.getBlock() instanceof AbstractRailBlock)) {
            // the rail may not have synced from the server yet
            if (++retries > 6) finish(); else timer = 1;
            return;
        }

        Vec3d hit = new Vec3d(railPos.getX() + 0.5, railPos.getY() + 0.125, railPos.getZ() + 0.5);
        if (mc.player.getEyePos().distanceTo(hit) > reach.get() + 0.5) {
            finish();
            return;
        }
        if (!Hotbar.select(Items.TNT_MINECART)) {
            finish();
            return;
        }

        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, Direction.UP, railPos, false));
        mc.player.swingHand(Hand.MAIN_HAND);
        retries = 0;
        timer = stepDelay.getInt();
        if (autoLight.get()) stage = 2; else finish();
    }

    private void light() {
        TntMinecartEntity cart = cartAt(railPos);
        if (cart == null) {
            // the cart entity may take a moment to appear
            if (++retries > 10) finish(); else timer = 1;
            return;
        }
        if (cart.isPrimed() || mc.player.distanceTo(cart) > reach.get() + 0.5 || !Hotbar.select(IGNITERS)) {
            finish();
            return;
        }

        mc.interactionManager.interactEntity(mc.player, cart, Hand.MAIN_HAND);
        mc.player.swingHand(Hand.MAIN_HAND);
        finish();
    }

    private TntMinecartEntity cartAt(BlockPos pos) {
        Vec3d center = Vec3d.ofCenter(pos);
        TntMinecartEntity best = null;
        double bestDist = 2.5 * 2.5;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof TntMinecartEntity cart) {
                double d = cart.squaredDistanceTo(center);
                if (d < bestDist) {
                    bestDist = d;
                    best = cart;
                }
            }
        }
        return best;
    }

    private Entity findTarget() {
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!Targets.matches(e, players.get(), mobs.get(), animals.get())) continue;
            double d = mc.player.distanceTo(e);
            if (d > targetRange.get() || d >= bestDist) continue;
            bestDist = d;
            best = e;
        }
        return best;
    }
}
