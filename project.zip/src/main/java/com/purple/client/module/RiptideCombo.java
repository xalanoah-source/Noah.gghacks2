package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Trident + mace combo helper. Launches you into the air with a Riptide trident
 * (only possible in water or rain), aimed a bit upward past the target. Mace Assist then
 * takes over: swaps to the mace as you fall and smashes. Run both modules together.
 */
public class RiptideCombo extends Module {
    private final NumberSetting launchRange = number("Launch Range", 12, 3, 40, 1);
    private final NumberSetting chargeTicks = number("Charge Ticks", 12, 10, 30, 1);
    private final NumberSetting aimLift = number("Aim Lift (deg)", 30, 0, 80, 5);
    private final BoolSetting autoSwap = bool("Auto Swap To Trident", true);
    private final NumberSetting relaunchDelay = number("Relaunch Delay (ticks)", 40, 0, 200, 10);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Hostile Mobs", true);
    private final BoolSetting animals = bool("Animals", false);

    private boolean charging;
    private int wait;

    public RiptideCombo() {
        super("Riptide Combo", "Riptide launch toward targets, then mace smash.", false);
    }

    @Override
    protected void onEnable() {
        charging = false;
        wait = 0;
    }

    @Override
    protected void onDisable() {
        if (charging && mc.player != null && mc.interactionManager != null) {
            mc.interactionManager.stopUsingItem(mc.player);
        }
        charging = false;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (wait > 0) wait--;
        if (mc.currentScreen != null || Freecam.active) return;

        if (charging) {
            // Riptide only fires in water/rain with a Riptide trident; bail out if anything changed.
            if (!mc.player.isUsingItem() || !holdingRiptideTrident() || !mc.player.isTouchingWaterOrRain()) {
                charging = false;
                return;
            }
            Entity t = findTarget();
            if (t != null) aimAt(t);
            if (mc.player.getItemUseTime() >= chargeTicks.getInt()) {
                mc.interactionManager.stopUsingItem(mc.player); // release = launch
                charging = false;
                wait = relaunchDelay.getInt();
            }
            return;
        }

        if (wait > 0) return;
        if (!mc.player.isTouchingWaterOrRain()) return; // never start a charge that would throw the trident
        Entity target = findTarget();
        if (target == null) return;

        if (!holdingRiptideTrident()) {
            if (autoSwap.get()) swapToTrident();
            return; // start charging next tick
        }

        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        charging = mc.player.isUsingItem();
    }

    private Entity findTarget() {
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (!Targets.matches(e, players.get(), mobs.get(), animals.get())) continue;
            double d = mc.player.distanceTo(e);
            if (d > launchRange.get() || d >= bestDist) continue;
            bestDist = d;
            best = e;
        }
        return best;
    }

    /** Snap the view toward the target, lifted upward so the launch carries you above it. */
    private void aimAt(Entity t) {
        Vec3d eye = mc.player.getEyePos();
        double dx = t.getX() - eye.x;
        double dy = t.getY() + t.getHeight() * 0.5 - eye.y;
        double dz = t.getZ() - eye.z;

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        targetPitch = MathHelper.clamp(targetPitch - aimLift.getF(), -90f, 90f);

        float dYaw = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float dPitch = targetPitch - mc.player.getPitch();
        // changeLookDirection scales by 0.15 (same as mouse input), so divide that back out.
        mc.player.changeLookDirection(dYaw / 0.15, dPitch / 0.15);
    }

    private static boolean hasRiptide(ItemStack stack) {
        if (!stack.isOf(Items.TRIDENT)) return false;
        return stack.getEnchantments().getEnchantments().stream()
                .anyMatch(e -> e.matchesKey(Enchantments.RIPTIDE));
    }

    private boolean holdingRiptideTrident() {
        return hasRiptide(mc.player.getMainHandStack());
    }

    private void swapToTrident() {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < PlayerInventory.HOTBAR_SIZE; i++) {
            if (hasRiptide(inv.getStack(i))) {
                inv.setSelectedSlot(i);
                return;
            }
        }
    }
}
