package com.purple.client.module;

import com.purple.client.setting.BoolSetting;
import com.purple.client.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.Locale;

/**
 * Mace combat helper (plain vanilla mechanics, no packet tricks):
 *  - tracks how far you've fallen,
 *  - swaps to a mace from your hotbar when you're falling toward a target,
 *  - hits the target under your crosshair once the fall is big enough and the mace is charged,
 *  - swaps back afterwards,
 *  - shows an estimate of the smash bonus damage.
 */
public class MaceAssist extends Module {
    private final NumberSetting minFall = number("Min Fall (blocks)", 3.0, 1.5, 30, 0.5);
    private final BoolSetting autoSwap = bool("Auto Swap To Mace", true);
    private final NumberSetting swapRange = number("Swap Range", 10, 3, 30, 1);
    private final BoolSetting swapBack = bool("Swap Back", true);
    private final BoolSetting autoAttack = bool("Auto Attack", true);
    private final NumberSetting range = number("Attack Range", 3.0, 1, 6, 0.5);
    private final NumberSetting minCooldown = number("Min Cooldown %", 100, 0, 100, 5);
    private final BoolSetting players = bool("Players", true);
    private final BoolSetting mobs = bool("Hostile Mobs", true);
    private final BoolSetting animals = bool("Animals", false);
    private final BoolSetting showInfo = bool("Show Smash Info", true);

    private double peakY;
    private double fall;
    private int previousSlot = -1;
    private int restoreDelay;

    public MaceAssist() {
        super("Mace Assist", "Auto-swap to mace, smash targets while falling.", false);
    }

    @Override
    protected void onEnable() {
        peakY = mc.player != null ? mc.player.getY() : 0;
        fall = 0;
        previousSlot = -1;
        restoreDelay = 0;
    }

    @Override
    protected void onDisable() {
        restore();
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        trackFall();
        handleRestore();

        if (mc.currentScreen != null || Freecam.active) return;
        boolean airborne = !mc.player.isOnGround();

        // Swap early (the mace's attack charge resets on swap, so it needs time to recharge).
        if (airborne && autoSwap.get() && fall >= 1.0 && !holdingMace() && hasTargetNear(swapRange.get())) {
            swapToMace();
        }

        if (!autoAttack.get() || !airborne || fall < minFall.get() || !holdingMace()) return;
        if (mc.interactionManager == null) return;

        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof EntityHitResult entityHit)) return;
        Entity target = entityHit.getEntity();
        if (!Targets.matches(target, players.get(), mobs.get(), animals.get())) return;
        if (mc.player.distanceTo(target) > range.get()) return;
        if (mc.player.getAttackCooldownProgress(0.5f) * 100f < minCooldown.get()) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(Hand.MAIN_HAND);
        peakY = mc.player.getY(); // a smash resets your fall distance
        if (previousSlot != -1) restoreDelay = 3;
    }

    /** Text for the HUD (under the crosshair), or null if nothing to show. */
    public String hudText() {
        if (!isEnabled() || !showInfo.get() || fall < 1.5) return null;
        return String.format(Locale.ROOT, "Fall %.1f  |  Smash ~+%.0f dmg", fall, smashBonus(fall));
    }

    /** Approximate bonus damage from the fall: +4/block for 3 blocks, +2/block for the next 5, +1/block after. */
    private static double smashBonus(double d) {
        return Math.min(d, 3) * 4 + Math.max(0, Math.min(d - 3, 5)) * 2 + Math.max(0, d - 8);
    }

    private void trackFall() {
        double y = mc.player.getY();
        if (mc.player.isOnGround() || mc.player.isTouchingWater() || mc.player.isClimbing()
                || mc.player.hasVehicle() || mc.player.getAbilities().flying) {
            peakY = y;
        } else {
            peakY = Math.max(peakY, y);
        }
        fall = Math.max(0, peakY - y);
    }

    private boolean holdingMace() {
        return mc.player.getMainHandStack().isOf(Items.MACE);
    }

    private boolean hasTargetNear(double radius) {
        for (Entity e : mc.world.getEntities()) {
            if (Targets.matches(e, players.get(), mobs.get(), animals.get())
                    && mc.player.distanceTo(e) <= radius) {
                return true;
            }
        }
        return false;
    }

    private void swapToMace() {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < PlayerInventory.HOTBAR_SIZE; i++) {
            if (inv.getStack(i).isOf(Items.MACE)) {
                if (swapBack.get() && previousSlot == -1) previousSlot = inv.getSelectedSlot();
                inv.setSelectedSlot(i);
                return;
            }
        }
    }

    private void handleRestore() {
        if (previousSlot == -1) return;
        if (restoreDelay > 0) {
            if (--restoreDelay == 0) restore();
            return;
        }
        if (mc.player.isOnGround() || fall < 0.5) restore();
    }

    private void restore() {
        if (previousSlot != -1 && mc.player != null) {
            mc.player.getInventory().setSelectedSlot(previousSlot);
        }
        previousSlot = -1;
    }
}
