package com.purple.client.module;

import java.util.Collections;
import java.util.List;

public class ModuleManager {
    public final AimAssist aimAssist = new AimAssist();
    public final TriggerBot triggerBot = new TriggerBot();
    public final MaceAssist maceAssist = new MaceAssist();
    public final RiptideCombo riptideCombo = new RiptideCombo();
    public final BaseFinder baseFinder = new BaseFinder();
    public final Freecam freecam = new Freecam();
    public final Fullbright fullbright = new Fullbright();
    public final AutoSprint autoSprint = new AutoSprint();

    private final List<Module> modules = List.of(
            aimAssist, triggerBot, maceAssist, riptideCombo,
            baseFinder, freecam, fullbright, autoSprint);

    public List<Module> all() { return Collections.unmodifiableList(modules); }

    public void tick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }

    public void onWorldLeave() {
        for (Module m : modules) {
            if (m.isEnabled() && m.disablesOnWorldLeave()) m.setEnabled(false);
        }
    }
}
